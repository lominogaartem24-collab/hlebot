const { REST, Routes, SlashCommandBuilder } = require('discord.js');

const commands = [
    new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('🍞 Создать тикет для поддержки'),
    new SlashCommandBuilder()
        .setName('close')
        .setDescription('🔒 Закрыть текущий тикет')
].map(cmd => cmd.toJSON());

const rest = new REST({ version: '10' }).setToken("MTQ4NTY3MjQ1NzExMjI1NjY2Mg.Gy7BV7.awqKY-qtMcj7NWYmRG37DY3MRa9fa6BusD8uNU");

(async () => {
    try {
        console.log('🔄 Регистрирую команды...');
        await rest.put(
            Routes.applicationCommands("1485672457112256662"),
            { body: commands }
        );
        console.log('✅ Команды зарегистрированы!');
    } catch (error) {
        console.error('❌ Ошибка регистрации:', error);
    }
})();