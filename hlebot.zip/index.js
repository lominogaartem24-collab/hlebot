const { Client, GatewayIntentBits, PermissionsBitField, ChannelType } = require('discord.js');

const client = new Client({
    intents: [GatewayIntentBits.Guilds]
});

const TOKEN = process.env.TOKEN;

const activeTickets = new Set();

client.once("ready", () => {
    console.log(`✅ Бот запущен как ${client.user.tag}`);
});

client.on("interactionCreate", async interaction => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === "ticket") {
        const existingChannel = interaction.guild.channels.cache.find(
            channel => channel.name === `ticket-${interaction.user.username}` && 
                       channel.type === ChannelType.GuildText
        );

        if (existingChannel) {
            return interaction.reply({
                content: `❌ У тебя уже есть открытый тикет: ${existingChannel}`,
                ephemeral: true
            });
        }

        try {
            const channel = await interaction.guild.channels.create({
                name: `ticket-${interaction.user.username}`,
                type: ChannelType.GuildText,
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        deny: [PermissionsBitField.Flags.ViewChannel]
                    },
                    {
                        id: interaction.user.id,
                        allow: [
                            PermissionsBitField.Flags.ViewChannel,
                            PermissionsBitField.Flags.SendMessages,
                            PermissionsBitField.Flags.ReadMessageHistory
                        ]
                    }
                ]
            });

            await channel.send(`🍞 Привет ${interaction.user}! Опиши свою проблему, и тебе помогут.\n\n💡 Для закрытия тикета используй команду \`/close\``);
            await interaction.reply({ 
                content: `✅ Тикет создан: ${channel}`, 
                ephemeral: true 
            });
            
            activeTickets.add(channel.id);
            
        } catch (error) {
            console.error(error);
            await interaction.reply({ 
                content: `❌ Ошибка при создании тикета. Проверь права бота.`, 
                ephemeral: true 
            });
        }
    }
    
    if (interaction.commandName === "close") {
        const channel = interaction.channel;
        
        if (!channel.name.startsWith("ticket-")) {
            return interaction.reply({ 
                content: "❌ Эту команду можно использовать только внутри тикета!", 
                ephemeral: true 
            });
        }
        
        const isOwner = channel.name === `ticket-${interaction.user.username}`;
        const isAdmin = interaction.member.permissions.has(PermissionsBitField.Flags.Administrator);
        
        if (!isOwner && !isAdmin) {
            return interaction.reply({ 
                content: "❌ Только создатель тикета или администратор могут закрыть его!", 
                ephemeral: true 
            });
        }
        
        try {
            await interaction.reply({ content: "🔒 Тикет будет закрыт через 3 секунды...", ephemeral: false });
            
            setTimeout(async () => {
                await channel.delete();
                activeTickets.delete(channel.id);
                console.log(`✅ Тикет ${channel.name} закрыт`);
            }, 3000);
            
        } catch (error) {
            console.error(error);
            await interaction.reply({ 
                content: "❌ Ошибка при закрытии тикета", 
                ephemeral: true 
            });
        }
    }
});

client.login(TOKEN);